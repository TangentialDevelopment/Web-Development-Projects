
var mast = document.getElementsByClassName("highlight");
mast[0].innerHTML = mast[0].innerHTML + "Test";

var idMast = document.getElementById("specific");
idMast.innerHTML = idMast.innerHTML + "Test";

# mi-349-resources
Files and Resources for MI 349 at Michigan State University
